# Mova ( Movie Streaming App UI )

This Repository Is Created for Implementing a online movie streaming application Complex UI

# App Under Development

# Full Preview


https://github.com/NimaNaderi/mova/assets/96233921/8bb789aa-5969-411a-8184-01a88bef7c6b



# Small App Preview
<img src="preview/images/0-light.jpg" alt="Description" width="250" height="auto"><img src="preview/images/0-dark.jpg" alt="Description" width="250" height="auto">
<img src="preview/images/1-light.jpg" alt="Description" width="250" height="auto"><img src="preview/images/1-dark.jpg" alt="Description" width="250" height="auto">
<img src="preview/images/2-light.jpg" alt="Description" width="250" height="auto"><img src="preview/images/2-dark.jpg" alt="Description" width="250" height="auto">
<img src="preview/images/3-light.jpg" alt="Description" width="250" height="auto"><img src="preview/images/3-dark.jpg" alt="Description" width="250" height="auto">
<img src="preview/images/4-light.jpg" alt="Description" width="250" height="auto"><img src="preview/images/4-dark.jpg" alt="Description" width="250" height="auto">
<img src="preview/images/5-light.jpg" alt="Description" width="250" height="auto"><img src="preview/images/5-dark.jpg" alt="Description" width="250" height="auto">
